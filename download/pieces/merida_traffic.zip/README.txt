Merida Traffic piece set

Original author: Armando Hernandez Marroquin
Color variant by: caderek (https://github.com/caderek)
License: GPLv2+ (https://www.gnu.org/licenses/gpl-2.0.txt)
Source: https://sharechess.github.io