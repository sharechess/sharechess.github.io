Reillycraig piece set

Author: Reilly Craig (https://instagram.com/fader_)
License: "free of charge" (https://www.chess.com/forum/view/suggestions/new-chess-set-design)
Source: https://sharechess.github.io