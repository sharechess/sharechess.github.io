Gioco piece set

Author: sadsnake1
License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/)
Source: https://sharechess.github.io