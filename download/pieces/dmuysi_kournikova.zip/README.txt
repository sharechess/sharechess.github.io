Dmuysi Kournikova piece set

Original author: Zach Bogart (https://thenounproject.com/zachbogart/)
Color variant by: caderek (https://github.com/caderek)
License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/)
Source: https://sharechess.github.io