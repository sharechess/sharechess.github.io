Trendy piece set

Author: Benjamin Kinard (https://thenounproject.com/sportsgator/)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io