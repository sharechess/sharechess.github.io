Symmetric piece set

Author: the lichobile authors (https://github.com/lichess-org/lichobile)
License: GNU GPL v3 (https://www.gnu.org/licenses/gpl-3.0.txt)
Source: https://sharechess.github.io