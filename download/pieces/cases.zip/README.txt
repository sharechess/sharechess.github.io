Cases piece set

Author: Matthieu Leschemelle, Armando Hernandez Marroquin
License: "freeware"
Source: https://sharechess.github.io