Chess7 Pink piece set

Original author: Sizenko Alexander aka Style-7 (http://www.styleseven.com/)
Color variant by: caderek (https://github.com/caderek)
License: "freeware"
Source: https://sharechess.github.io