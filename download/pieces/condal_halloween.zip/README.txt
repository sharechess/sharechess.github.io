Condal Halloween piece set

Original author: Armando Hernandez Marroquin
Color variant by: Isaiah Brown
License: "freeware
Source: https://sharechess.github.io