Companion piece set

Author: David L. Brown
License: "freeware" (http://www.enpassant.dk/chess/fonteng.htm#GC)
Source: https://sharechess.github.io