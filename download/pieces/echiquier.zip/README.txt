Echiquier piece set

Author: Vincent Tellier (https://www.vincent-tellier.fr/)
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://sharechess.github.io