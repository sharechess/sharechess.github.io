Traveller Brown piece set

Original author: Alan Cowderoy
Color variant by: caderek (https://github.com/caderek)
License: "freeware"
Source: https://sharechess.github.io