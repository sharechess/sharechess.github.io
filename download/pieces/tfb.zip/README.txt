Tfb piece set

Author: Kaiserzharkhan
License: "Free for personal use"
Source: https://sharechess.github.io