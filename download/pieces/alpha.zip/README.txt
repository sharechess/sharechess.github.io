Alpha piece set

Author: Eric Bentzen
License: "free for personal non commercial use"
Source: https://sharechess.github.io