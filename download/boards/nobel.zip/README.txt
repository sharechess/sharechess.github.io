Nobel chessboard

Author: caderek (https://github.com/caderek)
License: CC0 1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Source: https://sharechess.github.io