Pirouetti piece set

Author: pirouetti (https://lichess.org/@/pirouetti)
License: AGPLv3+ (https://www.gnu.org/licenses/agpl-3.0.txt)
Source: https://sharechess.github.io