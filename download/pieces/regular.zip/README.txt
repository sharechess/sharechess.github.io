Regular piece set

Author: Alastair Scott
License: "freeware"
Source: https://sharechess.github.io