Pirouetti Border Winter piece set

Original author: pirouetti (https://lichess.org/@/pirouetti)
Color variant by: caderek (https://github.com/caderek)
License: AGPLv3+ (https://www.gnu.org/licenses/agpl-3.0.txt)
Source: https://sharechess.github.io