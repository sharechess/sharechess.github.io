Smart piece set

Author: Christoph Wirth
License: "free"
Source: https://sharechess.github.io