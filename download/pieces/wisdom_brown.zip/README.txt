Wisdom Brown piece set

Original author: Vladimir Nikolic
Color variant by: caderek (https://github.com/caderek)
License: "Wisdom Chess is 100% free chess font! Enjoy!"
Source: https://sharechess.github.io