Qootee Pink piece set

Original author: Zaphroz (https://www.reddit.com/user/TangentialElephant)
Color variant by: caderek (https://github.com/caderek)
License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
Source: https://sharechess.github.io