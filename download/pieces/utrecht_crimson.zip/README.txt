Utrecht Crimson piece set

Original author: Hans Bodlaender
Color variant by: caderek (https://github.com/caderek)
License: "freeware"
Source: https://sharechess.github.io