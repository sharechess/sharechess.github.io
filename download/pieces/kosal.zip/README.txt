Kosal piece set

Author: Philatype (https://github.com/philatype)
License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
Source: https://sharechess.github.io