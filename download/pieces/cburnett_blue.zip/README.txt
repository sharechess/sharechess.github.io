Cburnett Blue piece set

Original author: Colin M.L. Burnett (https://en.wikipedia.org/wiki/User:Cburnett)
Color variant by: caderek (https://github.com/caderek)
License: GPLv2+ (https://www.gnu.org/licenses/gpl-2.0.txt)
Source: https://sharechess.github.io