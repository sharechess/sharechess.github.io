Letters Warm piece set

Original author: unknown
Color variant by: caderek (https://github.com/caderek)
License: unknown
Source: https://sharechess.github.io