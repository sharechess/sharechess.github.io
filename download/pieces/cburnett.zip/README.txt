Cburnett piece set

Author: Colin M.L. Burnett (https://en.wikipedia.org/wiki/User:Cburnett)
License: GPLv2+ (https://www.gnu.org/licenses/gpl-2.0.txt)
Source: https://sharechess.github.io