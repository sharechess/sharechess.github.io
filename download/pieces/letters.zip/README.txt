Letters piece set

Author: unknown
License: unknown
Source: https://sharechess.github.io