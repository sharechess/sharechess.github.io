Riohacha piece set

Author: the lila authors (https://github.com/lichess-org/lila)
License: AGPLv3+ (https://www.gnu.org/licenses/agpl-3.0.txt)
Source: https://sharechess.github.io