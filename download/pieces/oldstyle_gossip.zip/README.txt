Oldstyle Gossip piece set

Original author: Monika Berger
Color variant by: caderek (https://github.com/caderek)
License: Non-Commercial
Source: https://sharechess.github.io