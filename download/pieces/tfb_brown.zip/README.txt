Tfb Brown piece set

Original author: Kaiserzharkhan
Color variant by: caderek (https://github.com/caderek)
License: "Free for personal use"
Source: https://sharechess.github.io