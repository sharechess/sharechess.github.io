Symmetric Blue piece set

Original author: the lichobile authors (https://github.com/lichess-org/lichobile)
Color variant by: caderek (https://github.com/caderek)
License: GNU GPL v3 (https://www.gnu.org/licenses/gpl-3.0.txt)
Source: https://sharechess.github.io