Adventurer Brown piece set

Original author: Armando Hernandez Marroquin
Color variant by: caderek (https://github.com/caderek)
License: "freeware"
Source: https://sharechess.github.io