Echiquier Flesh piece set

Original author: Vincent Tellier (https://www.vincent-tellier.fr/)
Color variant by: caderek (https://github.com/caderek)
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://sharechess.github.io