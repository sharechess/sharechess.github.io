Letters Warm piece set

Original author: caderek (https://github.com/caderek)
Color variant by: caderek (https://github.com/caderek)
License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/)
Source: https://sharechess.github.io