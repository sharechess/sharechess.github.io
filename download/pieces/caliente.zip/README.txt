Caliente piece set

Author: Leonid Gordenin "avi" (https://github.com/avi-0)
License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/)
Source: https://sharechess.github.io