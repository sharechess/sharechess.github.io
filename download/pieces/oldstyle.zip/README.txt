Oldstyle piece set

Author: Monika Berger
License: Non-Commercial
Source: https://sharechess.github.io