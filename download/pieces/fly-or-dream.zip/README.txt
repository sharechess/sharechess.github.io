Fly Or Dream piece set

Author: DG-RA (https://www.reddit.com/user/RaF_zz/)
License: PDM 1.0 (https://creativecommons.org/publicdomain/mark/1.0/)
Source: https://sharechess.github.io