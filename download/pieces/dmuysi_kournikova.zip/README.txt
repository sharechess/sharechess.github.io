Dmuysi Kournikova piece set

Original author: Zach Bogart (https://thenounproject.com/zachbogart/)
Color variant by: caderek (https://github.com/caderek)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io