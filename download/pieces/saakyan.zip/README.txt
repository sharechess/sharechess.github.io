Saakyan piece set

Author: Sergey Saakyan (https://thenounproject.com/seregasa/)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io