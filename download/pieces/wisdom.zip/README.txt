Wisdom piece set

Author: Vladimir Nikolic
License: "Wisdom Chess is 100% free chess font! Enjoy!"
Source: https://sharechess.github.io