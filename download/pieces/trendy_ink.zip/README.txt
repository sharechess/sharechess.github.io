Trendy Ink piece set

Original author: Benjamin Kinard (https://thenounproject.com/sportsgator/)
Color variant by: caderek (https://github.com/caderek)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io