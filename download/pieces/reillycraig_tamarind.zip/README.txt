Reillycraig Tamarind piece set

Original author: Reilly Craig (https://instagram.com/fader_)
Color variant by: caderek (https://github.com/caderek)
License: "free of charge" (https://www.chess.com/forum/view/suggestions/new-chess-set-design)
Source: https://sharechess.github.io