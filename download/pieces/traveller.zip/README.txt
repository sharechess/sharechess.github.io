Traveller piece set

Author: Alan Cowderoy
License: "freeware"
Source: https://sharechess.github.io