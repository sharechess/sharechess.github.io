Dmuysi piece set

Author: Zach Bogart (https://thenounproject.com/zachbogart/)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io