Utrecht piece set

Author: Hans Bodlaender
License: "freeware"
Source: https://sharechess.github.io