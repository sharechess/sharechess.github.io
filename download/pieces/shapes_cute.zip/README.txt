Shapes Cute piece set

Original author: flugsio (https://github.com/flugsio/chess_shapes)
Color variant by: caderek (https://github.com/caderek)
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://sharechess.github.io