Pixel piece set

Author: therealqtpi (https://twitter.com/therealqtpi)
License: AGPLv3+ (https://www.gnu.org/licenses/agpl-3.0.txt)
Source: https://sharechess.github.io