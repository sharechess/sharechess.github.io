Icon54 Brown piece set

Original author: icon 54 (https://thenounproject.com/icon54app/)
Color variant by: caderek (https://github.com/caderek)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io