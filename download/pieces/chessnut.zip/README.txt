Chessnut piece set

Author: Alexis Luengas (https://github.com/LexLuengas)
License: Apache 2.0 (https://github.com/LexLuengas/chessnut-pieces/blob/master/LICENSE.txt)
Source: https://sharechess.github.io