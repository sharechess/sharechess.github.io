Alfarishy piece set

Author: Jordan Alfarishy (https://thenounproject.com/joalfa/)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io