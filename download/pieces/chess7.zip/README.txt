Chess7 piece set

Author: Sizenko Alexander aka Style-7 (http://www.styleseven.com/)
License: "freeware"
Source: https://sharechess.github.io