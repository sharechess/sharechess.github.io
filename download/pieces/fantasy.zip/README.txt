Fantasy piece set

Author: Maurizio Monge (http://poisson.phc.unipi.it/~monge/chess_art.php)
License: "give credit in a suitable way"
Source: https://sharechess.github.io