Companion Red piece set

Original author: David L. Brown
Color variant by: caderek (https://github.com/caderek)
License: "freeware" (http://www.enpassant.dk/chess/fonteng.htm#GC)
Source: https://sharechess.github.io