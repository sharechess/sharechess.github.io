Cases Gray piece set

Original author: Matthieu Leschemelle, Armando Hernandez Marroquin
Color variant by: caderek (https://github.com/caderek)
License: "freeware"
Source: https://sharechess.github.io