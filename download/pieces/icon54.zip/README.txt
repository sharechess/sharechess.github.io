Icon54 piece set

Author: icon 54 (https://thenounproject.com/icon54app/)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io