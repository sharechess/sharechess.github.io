Berlin Maroon piece set

Original author: Eric Bentzen
Color variant by: caderek (https://github.com/caderek)
License: "free for personal non commercial use"
Source: https://sharechess.github.io