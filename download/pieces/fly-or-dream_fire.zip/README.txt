Fly Or Dream Fire piece set

Original author: DG-RA (https://www.reddit.com/user/RaF_zz/)
Color variant by: caderek (https://github.com/caderek)
License: PDM 1.0 (https://creativecommons.org/publicdomain/mark/1.0/)
Source: https://sharechess.github.io