Line piece set

Author: Armando Hernandez Marroquin
License: "freeware"
Source: https://sharechess.github.io