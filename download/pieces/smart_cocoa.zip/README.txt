Smart Cocoa piece set

Original author: Christoph Wirth
Color variant by: caderek (https://github.com/caderek)
License: "free"
Source: https://sharechess.github.io