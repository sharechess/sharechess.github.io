Vecon piece set

Author: vecon (https://thenounproject.com/vecon/)
License: CC BY 3.0 (https://creativecommons.org/licenses/by/3.0/)
Source: https://sharechess.github.io