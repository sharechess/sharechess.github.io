Chessnut Burgundy piece set

Original author: Alexis Luengas (https://github.com/LexLuengas)
Color variant by: caderek (https://github.com/caderek)
License: Apache 2.0 (https://github.com/LexLuengas/chessnut-pieces/blob/master/LICENSE.txt)
Source: https://sharechess.github.io