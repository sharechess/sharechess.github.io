Shapes piece set

Author: flugsio (https://github.com/flugsio/chess_shapes)
License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
Source: https://sharechess.github.io