Pirat piece set

Author: Klaus Wolf
License: "freeware"
Source: https://sharechess.github.io