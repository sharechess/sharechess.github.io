Fantasy Cold piece set

Original author: Maurizio Monge (http://poisson.phc.unipi.it/~monge/chess_art.php)
Color variant by: caderek (https://github.com/caderek)
License: "give credit in a suitable way"
Source: https://sharechess.github.io