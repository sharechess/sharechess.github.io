Pirat Maroon piece set

Original author: Klaus Wolf
Color variant by: caderek (https://github.com/caderek)
License: "freeware"
Source: https://sharechess.github.io