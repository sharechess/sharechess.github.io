California piece set

Author: Jerry S. (https://sites.google.com/view/jerrychess/home)
License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/)
Source: https://sharechess.github.io